create user 'Somellier' identified by "1234";
GRANT SELECT ON LojaDeVinhos.Vinho TO 'Somellier';
GRANT SELECT (codVinicola) ON LojaDeVinhos.Vinicola TO 'Somellier';
