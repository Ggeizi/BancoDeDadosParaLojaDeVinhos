select * from LojaDeVinhos.Regiao;
select * from LojaDeVinhos.Vinicola;
select * from LojaDeVinhos.Vinho;