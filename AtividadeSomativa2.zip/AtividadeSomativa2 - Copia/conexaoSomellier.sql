select codVinicola from LojaDeVinhos.Vinicola;
select * from LojaDeVinhos.Vinho;