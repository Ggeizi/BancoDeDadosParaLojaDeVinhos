insert into LojaDeVinhos.Regiao values
	(1, "Vale dos vinhedos", "Vinhos finos de alta qualidade"),
    (2, "Serra Gaucha", "Tradição Italiana e destaque em espumantes"),
    (3, "Campanha Gaúcha", "Referência em vinhos tintos encorpados"),
    (4, "Bordeaux", "Vinhos tintos de corte com Cabernet Sauvignon e Merlot"),
    (5, "Toscana", "Forte identidade cultural e histórica");
    
insert into LojaDeVinhos.Vinicola values
	(111, "Lídio Carraro", "RS-Brasil", "1122223333", "lidio@vinhos", 1),
    (222, "Salton", "RS-Brasil", "4455556666", "salton@vinhos", 2),
    (333, "Vinicola Almadén", "RS-Brasil", "2244446666", "almaden@vinhos", 3),
    (444, "Chateau Latour", "França", "7755553333", "latour@vinhos", 4),
    (555, "Frescobaldi", "Italia", "1199995555", "frescobaldi@vinhos", 5);
    
insert into LojaDeVinhos.Vinho values
    (123, "Miolo Seleção", "Tinto", 2020, "frutado", 111),
    (234, "Casa Valduga Merlot", "suave", 2019, "vinho elegante e suave", 222),
    (345, "Salton Intenso Tamat", "estruturado", 2020, "cor profunda", 333),
    (456, "Chanteau", "Bordeaux", 2018, "complexo e sofisticado", 444),
    (567, "Tignanello", "Supertoscano", 2019, "intenso e elegante", 555);